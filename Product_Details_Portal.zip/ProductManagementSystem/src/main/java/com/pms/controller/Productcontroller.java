package com.pms.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.jsp.JspWriter;

import com.pms.entity.Product;
import com.pms.service.ProductService;

/**
 * Servlet implementation class Productcontroller
 */
@WebServlet("/Productcontroller")
public class Productcontroller extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Productcontroller() {
        super();
        // TODO Auto-generated constructor stub
    }

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		ProductService ps = new ProductService();
		List<Product> listOfProduct=ps.findAllProduct();
		
		HttpSession hs = request.getSession();
		hs.setAttribute("products", listOfProduct);
		
		response.sendRedirect("displayProduct.jsp");
		response.setContentType("text/html");
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter pw= response.getWriter();
		String pname=request.getParameter("pname");
		float price=Float.parseFloat(request.getParameter("price"));
		
		// convert those value to objects. 
		
				Product p = new Product();
				p.setPname(pname);
				p.setPrice(price);
			
				
				// created service class object. 
				ProductService ps = new ProductService();
				String result = ps.storeProduct(p);
				pw.print(result);
				RequestDispatcher rd = request.getRequestDispatcher("addProduct.jsp");
				rd.include(request, response);
				response.setContentType("text/html");
				

	}

}
