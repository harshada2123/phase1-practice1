import java.io.File;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.IOException;

public class FileCD {
    public static void main(String[] args) {
   
        String fileName = "programfile";

        createFile(fileName);

        readFile(fileName);
        
        updateFile(fileName, "content.");

        readFile(fileName);

        deleteFile(fileName);
    }

    private static void createFile(String fileName) {
        try {
            
            FileWriter writer = new FileWriter(fileName);

     
            writer.write("Hello, this is a file handling \n");
            writer.write("Creating a new file.");

            
            writer.close();

            System.out.println("File created successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void readFile(String fileName) {
        try {
            FileReader reader = new FileReader(fileName);

            
            BufferedReader bufferedReader = new BufferedReader(reader);

            System.out.println("\nReading data from the file:");

            
            String line;
            while ((line = bufferedReader.readLine()) != null) {
                System.out.println(line);
            }

          
            bufferedReader.close();
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void updateFile(String fileName, String updatedContent) {
        try {
         
            FileWriter writer = new FileWriter(fileName, true);
            
            BufferedWriter bufferedWriter = new BufferedWriter(writer);

            
            bufferedWriter.newLine(); 
            bufferedWriter.write(updatedContent);

            
            bufferedWriter.close();
            writer.close();

            System.out.println("\nFile updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static void deleteFile(String fileName) {
        
        File file = new File(fileName);

       
        if (file.delete()) {
            System.out.println("\nFile deleted successfully.");
        } else {
            System.out.println("\nFailed to delete the file.");
        }
    }
}

